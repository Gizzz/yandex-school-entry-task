module.exports.index = function (req, res) {
  res.send(`
    <html>
      <head>
        <title>Shri 2018</title>
        <script src="/scripts/test.js"></script>
      </head>
      <h1>Hello</h1>
    </html>
    `);
};
